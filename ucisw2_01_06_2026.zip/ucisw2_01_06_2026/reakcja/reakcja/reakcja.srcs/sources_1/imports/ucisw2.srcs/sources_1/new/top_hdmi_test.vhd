library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

library UNISIM;
use UNISIM.VComponents.ALL;

entity top_hdmi_test is
    port (
        clk_p     : in  std_logic;
        clk_n     : in  std_logic;
        rst       : in  std_logic;
        led       : out std_logic_vector(3 downto 0);

        HDMI_D0_P : out std_logic;
        HDMI_D0_N : out std_logic;
        HDMI_D1_P : out std_logic;
        HDMI_D1_N : out std_logic;
        HDMI_D2_P : out std_logic;
        HDMI_D2_N : out std_logic;
        HDMI_CK_P : out std_logic;
        HDMI_CK_N : out std_logic
    );
end top_hdmi_test;

architecture Behavioral of top_hdmi_test is

    signal clk_s        : std_logic;
    signal pxClk_s      : std_logic;
    signal pxClkX5_s    : std_logic;
    signal clk_locked_s : std_logic;

    signal hdmi_rst_s   : std_logic;
    signal de_s         : std_logic;
    signal hsync_s      : std_logic;
    signal vsync_s      : std_logic;
    signal posx_s       : std_logic_vector(9 downto 0);
    signal posy_s       : std_logic_vector(9 downto 0);
    signal r_s          : std_logic_vector(7 downto 0);
    signal g_s          : std_logic_vector(7 downto 0);
    signal b_s          : std_logic_vector(7 downto 0);

begin

    u_ibufds : IBUFDS
        port map (
            I  => clk_p,
            IB => clk_n,
            O  => clk_s
        );

    u_clk_hdmi : entity work.clk_wiz_hdmi
        port map (
            clk_in1  => clk_s,
            reset    => rst,
            clk_out1 => pxClk_s,
            clk_out2 => pxClkX5_s,
            locked   => clk_locked_s
        );

    hdmi_rst_s <= rst or (not clk_locked_s);

    u_vtim : entity work.VideoTiming
        port map (
            pixClk => pxClk_s,
            ResetN => not hdmi_rst_s,
            DE     => de_s,
            HSync  => hsync_s,
            VSync  => vsync_s,
            PosX   => posx_s,
            PosY   => posy_s
        );

    u_img : entity work.ImgGen
        port map (
            Clk  => pxClk_s,
            RstN => not hdmi_rst_s,
            PosX => posx_s,
            PosY => posy_s,
            R    => r_s,
            G    => g_s,
            B    => b_s
        );

    u_hdmi : entity work.HDMI_TX_wrap
        port map (
            pxClk     => pxClk_s,
            pxClkX5   => pxClkX5_s,
            ResetN    => not hdmi_rst_s,
            DE        => de_s,
            HSync     => hsync_s,
            VSync     => vsync_s,
            R         => r_s,
            G         => g_s,
            B         => b_s,
            HDMI_D0_P => HDMI_D0_P,
            HDMI_D0_N => HDMI_D0_N,
            HDMI_D1_P => HDMI_D1_P,
            HDMI_D1_N => HDMI_D1_N,
            HDMI_D2_P => HDMI_D2_P,
            HDMI_D2_N => HDMI_D2_N,
            HDMI_CK_P => HDMI_CK_P,
            HDMI_CK_N => HDMI_CK_N
        );

    led(0) <= clk_locked_s;
    led(1) <= de_s;
    led(2) <= hsync_s;
    led(3) <= vsync_s;

end Behavioral;
