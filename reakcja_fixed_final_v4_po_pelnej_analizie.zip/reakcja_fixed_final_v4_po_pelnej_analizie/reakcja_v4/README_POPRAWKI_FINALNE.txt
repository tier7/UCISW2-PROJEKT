POPRAWKI WPROWADZONE DO PROJEKTU REAKCJA
========================================

Najważniejsze zmiany:

1. Naprawa HDMI:
   - W module top_reaction_ps2_demo.vhd zamieniono podłączenie wyjść Clocking Wizard.
   - clk_out1 z IP ma 125 MHz i jest teraz podłączony do pxClkX5.
   - clk_out2 z IP ma 25 MHz i jest teraz podłączony do pxClk.
   - To była bardzo prawdopodobna przyczyna braku obrazu, bo wcześniej zegary HDMI były podłączone odwrotnie.

2. Zastosowanie plików prowadzącego:
   - Dodano VideoTiming.vhd z pliku dostarczonego przez prowadzącego.
   - Dodano ImgGen.vhd z pliku dostarczonego przez prowadzącego.
   - top_reaction_ps2_demo.vhd używa teraz VideoTiming jako generatora synchronizacji 640x480@60 Hz.
   - ImgGen generuje tło testowe, a projekt nakłada na nie właściwy kwadrat reakcji.

3. Poprawa logiki obrazu:
   - reaction_video.vhd używa tła z ImgGen i nakłada centralny kwadrat:
     * czerwony podczas oczekiwania,
     * zielony podczas pomiaru reakcji,
     * niebieski po zakończeniu testu,
     * szary w spoczynku.

4. Poprawa losowego czasu opóźnienia:
   - random_delay.vhd został poprawiony tak, aby faktycznie losował opóźnienie z zakresu 1000-3000 ms.
   - Poprzednia wersja liczyła modulo z liczby cykli zegara, ale LFSR miał tylko 16 bitów, więc realny zakres losowości był bardzo mały.
   - LFSR miesza się cały czas w stanie bezczynności, więc moment naciśnięcia START wpływa na wybrany czas.

5. Poprawa obsługi START:
   - W top_reaction_ps2.vhd dodano synchronizację przycisku START i impuls jednocyklowy.
   - Zmniejsza to ryzyko wielokrotnego startu przez dłuższe przytrzymanie przycisku.

Co trzeba zrobić w Vivado:

1. Otwórz reakcja.xpr.
2. Upewnij się, że top module to top_reaction_ps2_demo.
3. W Clocking Wizard dla clk_wiz_hdmi powinno być:
   - clk_out1 = 125 MHz,
   - clk_out2 = 25 MHz.
4. Uruchom Generate Bitstream od nowa.
5. Nie używaj starego pliku bit z poprzedniej implementacji, bo był wygenerowany przed poprawkami.

Uwaga:
Nie wygenerowano tutaj nowego pliku .bit, bo w środowisku ChatGPT nie ma uruchomionego Vivado. Projekt źródłowy został poprawiony i powinien zostać ponownie zsyntetyzowany oraz zaimplementowany w Vivado.
