REAKCJA - analiza i poprawki V4

Najważniejsza poprawka względem V3:
- OLED nie pokazuje już po resecie mylącego komunikatu TRY1 0000 FAST.
- Po zakończeniu próby OLED pokazuje numer zakończonej próby, np. TRY1 0245 FAST, a nie numer następnej próby.
- Dodano sygnał completed_trial_dbg, który przechowuje numer ostatnio zakończonej próby.
- OLED pokazuje stany: PRESS START, TRYn WAIT, TRYn PRESS, TRYn ERROR, TRYn xxxx FAST/GOOD/OK/SLOW, AVG xxxx ...

Pozostałe elementy pozostają zgodne z V3:
- VideoTiming.vhd i ImgGen.vhd są plikami prowadzącego i są używane w top_reaction_ps2_demo.vhd.
- HDMI_TX dostaje pxClk=25 MHz oraz pxClkX5=125 MHz z clk_wiz_hdmi.
- Losowe opóźnienie bodźca: 1000-3000 ms.
- Pomiar reakcji w ms, 5 prób, średnia po 5 próbach.
- PS/2 służy do reakcji użytkownika, OLED_ASCII do tekstowego wyniku, HDMI do obrazu.

Po otwarciu w Vivado trzeba wygenerować bitstream od nowa.
