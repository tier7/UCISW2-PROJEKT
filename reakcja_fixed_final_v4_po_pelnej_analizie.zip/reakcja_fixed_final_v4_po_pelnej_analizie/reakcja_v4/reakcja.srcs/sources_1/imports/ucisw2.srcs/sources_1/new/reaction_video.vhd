library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity reaction_video is
    port (
        hcount    : in  unsigned(10 downto 0);
        vcount    : in  unsigned(10 downto 0);
        de        : in  std_logic;
        red_on    : in  std_logic;
        green_on  : in  std_logic;
        test_done : in  std_logic;
        bg_R      : in  std_logic_vector(7 downto 0);
        bg_G      : in  std_logic_vector(7 downto 0);
        bg_B      : in  std_logic_vector(7 downto 0);
        R         : out std_logic_vector(7 downto 0);
        G         : out std_logic_vector(7 downto 0);
        B         : out std_logic_vector(7 downto 0)
    );
end reaction_video;

architecture Behavioral of reaction_video is
begin

    process(hcount, vcount, de, red_on, green_on, test_done, bg_R, bg_G, bg_B)
        variable r_v       : std_logic_vector(7 downto 0);
        variable g_v       : std_logic_vector(7 downto 0);
        variable b_v       : std_logic_vector(7 downto 0);
        variable in_square : boolean;
    begin
        r_v := (others => '0');
        g_v := (others => '0');
        b_v := (others => '0');

        -- Kwadrat bodźca na środku ekranu 640x480.
        in_square := (hcount >= 220 and hcount < 420 and
                      vcount >= 140 and vcount < 340);

        if de = '1' then
            -- Tło pochodzi z modułu ImgGen dostarczonego przez prowadzącego.
            r_v := bg_R;
            g_v := bg_G;
            b_v := bg_B;

            if in_square then
                if red_on = '1' then
                    r_v := x"FF";
                    g_v := x"00";
                    b_v := x"00";
                elsif green_on = '1' then
                    r_v := x"00";
                    g_v := x"FF";
                    b_v := x"00";
                elsif test_done = '1' then
                    r_v := x"00";
                    g_v := x"00";
                    b_v := x"FF";
                else
                    r_v := x"FF";
                    g_v := x"FF";
                    b_v := x"FF";
                end if;
            end if;
        end if;

        R <= r_v;
        G <= g_v;
        B <= b_v;
    end process;

end Behavioral;
