library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity ImgGen is
    Port (
           Clk  : in STD_LOGIC;
           RstN : in STD_LOGIC;
           PosX : in  STD_LOGIC_VECTOR (9 downto 0);
           PosY : in  STD_LOGIC_VECTOR (9 downto 0);
           R    : out STD_LOGIC_VECTOR (7 downto 0);
           G    : out STD_LOGIC_VECTOR (7 downto 0);
           B    : out STD_LOGIC_VECTOR (7 downto 0)
        );
end ImgGen;

architecture Behavioral of ImgGen is
begin

    process(PosX, PosY, Clk, RstN)
    begin
        R <= (others => '0');
        G <= (others => '0');
        B <= (others => '0');
    end process;

end Behavioral;