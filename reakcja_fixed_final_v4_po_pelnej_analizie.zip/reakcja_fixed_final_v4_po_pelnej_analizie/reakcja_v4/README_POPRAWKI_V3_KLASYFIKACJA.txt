Poprawki V3 - klasyfikacja czasu reakcji na OLED
=================================================

Zmiana względem V2:
- GOOD/BAD nie jest już mylone z klasyfikacją jakości czasu.
- BAD/ERROR oznacza błąd logiczny próby: naciśnięcie klawisza przed zielonym bodźcem albo brak reakcji do końca zakresu pomiarowego.
- Wolna, ale wykonana reakcja nie jest błędem. Jest wyświetlana jako SLOW.

Klasyfikacja wyświetlana na OLED:
- 0..250 ms      -> FAST
- 251..500 ms    -> GOOD
- 501..1000 ms   -> OK
- powyżej 1000 ms -> SLOW

Przykłady komunikatów:
- TRY1 0185 FAST
- TRY2 0340 GOOD
- TRY3 0780 OK
- TRY4 2300 SLOW
- TRY5 ERROR      (reakcja przed bodźcem lub brak reakcji do końca zakresu)
- AVG 0325 GOOD
- AVG 1500 SLOW

Limit techniczny pomiaru:
- MAX_REACTION_MS ustawiono na 9999 ms, ponieważ OLED pokazuje czas w 4 cyfrach.
- Około 10 sekund nie daje już automatycznie GOOD, tylko SLOW / ewentualnie ERROR po przekroczeniu zakresu.

Zmienione pliki:
- reaction_fsm.vhd
- top_reaction_test.vhd
- top_reaction_ps2.vhd
- oled_ascii_formatter.vhd

Po otwarciu projektu w Vivado trzeba wygenerować bitstream od nowa.
